CRC32
=====

An Arduino library for calculating a CRC32 checksum.
